<?php
include 'config/db.php';

echo "<h2>Testing Database Connection</h2>";

if ($conn) {
    echo "✅ Connected successfully!<br>";
    
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM pets");
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        echo "✅ Total pets: " . $row['total'] . "<br>";
        
        // Show some pets
        $result = mysqli_query($conn, "SELECT name, type, breed FROM pets LIMIT 3");
        if ($result) {
            echo "<h3>Sample Pets:</h3><ul>";
            while ($pet = mysqli_fetch_assoc($result)) {
                echo "<li>" . $pet['name'] . " - " . $pet['type'] . " (" . $pet['breed'] . ")</li>";
            }
            echo "</ul>";
        }
    } else {
        echo "❌ Query failed: " . mysqli_error($conn);
    }
} else {
    echo "❌ Connection failed!";
}
?>
