-- Create database
CREATE DATABASE IF NOT EXISTS pet_adoption;
USE pet_adoption;

-- Users table with plain text passwords for vulnerability
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample users
INSERT INTO users (username, email, password, role) VALUES
('admin', 'admin@petadoption.com', 'admin123', 'admin'),
('john_doe', 'john@email.com', 'password123', 'user'),
('jane_smith', 'jane@email.com', 'qwerty456', 'user'),
('pet_lover', 'petlover@email.com', 'lovepets789', 'user');

-- Pets table
CREATE TABLE pets (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(50) NOT NULL,
    breed VARCHAR(100),
    age INT,
    description TEXT,
    status ENUM('available', 'pending', 'adopted') DEFAULT 'available',
    added_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (added_by) REFERENCES users(id)
);

-- Insert sample pets
INSERT INTO pets (name, type, breed, age, description, status, added_by) VALUES
('Max', 'Dog', 'Golden Retriever', 24, 'Friendly and energetic dog, good with children', 'available', 1),
('Luna', 'Cat', 'Persian', 12, 'Calm and affectionate cat', 'available', 1),
('Buddy', 'Dog', 'Labrador', 36, 'Very loyal and protective', 'pending', 2),
('Milo', 'Cat', 'Siamese', 8, 'Playful and vocal cat', 'available', 3),
('Rocky', 'Dog', 'German Shepherd', 48, 'Intelligent and trainable', 'adopted', 1),
('Bella', 'Cat', 'Maine Coon', 18, 'Gentle giant, good with other pets', 'available', 2),
('Charlie', 'Dog', 'Poodle', 15, 'Hypoallergenic, very smart', 'available', 3);

-- Adoption applications
CREATE TABLE adoptions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    pet_id INT,
    user_id INT,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    application_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    message TEXT,
    FOREIGN KEY (pet_id) REFERENCES pets(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert sample applications
INSERT INTO adoptions (pet_id, user_id, status, message) VALUES
(1, 2, 'approved', 'I have a big backyard and love dogs!'),
(3, 3, 'pending', 'Looking for a companion for my family'),
(5, 4, 'rejected', 'Would love to adopt Rocky');

-- Feedback/comments
CREATE TABLE feedback (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    comment TEXT,
    rating INT DEFAULT 5,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert sample feedback
INSERT INTO feedback (user_id, comment, rating) VALUES
(1, 'Great platform for finding pets!', 5),
(2, 'Found my best friend here!', 5),
(3, 'Easy to use and lots of options', 4),
(1, 'Very helpful staff', 5);

-- Saved pets (favorites)
CREATE TABLE saved_pets (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    pet_id INT,
    saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (pet_id) REFERENCES pets(id) ON DELETE CASCADE,
    UNIQUE KEY unique_save (user_id, pet_id)
);
