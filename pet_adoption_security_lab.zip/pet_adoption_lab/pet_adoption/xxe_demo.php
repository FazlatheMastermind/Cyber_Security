<?php
session_start();
include 'config/db.php';

$message = "";
$parsed_data = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['xml_file'])) {
    $xml_content = file_get_contents($_FILES['xml_file']['tmp_name']);
    
    $dom = new DOMDocument();
    $dom->loadXML($xml_content, LIBXML_NOENT | LIBXML_DTDLOAD);
    
    $xml = simplexml_import_dom($dom);
    $parsed_data = print_r($xml, true);
    
    $message = "XML parsed successfully!";
}
?>
<?php include 'includes/header.php'; ?>

<div class="card">
    <h2>📄 XXE Vulnerability Demo</h2>
    
    <div style="background: #d1ecf1; padding: 15px; border-radius: 5px; margin: 15px 0; border: 1px solid #bee5eb;">
        <strong>⚠️ XXE Test Payloads:</strong><br>
        <code style="background: white; padding: 2px 5px; border-radius: 3px; display: block; margin: 5px 0;">
            &lt;!DOCTYPE foo [&lt;!ENTITY xxe SYSTEM "file:///etc/passwd"&gt;]&gt;
        </code>
        <code style="background: white; padding: 2px 5px; border-radius: 3px; display: block; margin: 5px 0;">
            &lt;!DOCTYPE foo [&lt;!ENTITY xxe SYSTEM "http://localhost:8080/evil.dtd"&gt;]&gt;
        </code>
    </div>
    
    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label>Upload XML File</label>
            <input type="file" name="xml_file" accept=".xml" required>
        </div>
        <button type="submit" class="btn btn-primary">Parse XML</button>
    </form>
    
    <?php if($message): ?>
    <div class="message"><?php echo $message; ?></div>
    <?php endif; ?>
    
    <?php if($parsed_data): ?>
    <div class="debug-box">
        <strong>📊 Parsed XML Data:</strong><br>
        <?php echo nl2br(htmlspecialchars($parsed_data)); ?>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
