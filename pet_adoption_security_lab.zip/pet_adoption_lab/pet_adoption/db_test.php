<?php
include 'config/db.php';
echo "Database connected!<br>";
$result = mysqli_query($conn, "SELECT COUNT(*) as total FROM pets");
$row = mysqli_fetch_assoc($result);
echo "Total pets: " . $row['total'];
?>
