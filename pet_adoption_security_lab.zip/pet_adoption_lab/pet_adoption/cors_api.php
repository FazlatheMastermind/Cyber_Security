<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: *");
header("Content-Type: application/json");

$data = [
    "pets" => [
        ["id" => 1, "name" => "Max", "type" => "Dog", "status" => "available"],
        ["id" => 2, "name" => "Luna", "type" => "Cat", "status" => "available"],
        ["id" => 3, "name" => "Buddy", "type" => "Dog", "status" => "pending"]
    ],
    "sensitive_data" => "This data is exposed due to CORS misconfiguration!"
];

echo json_encode($data);
?>
