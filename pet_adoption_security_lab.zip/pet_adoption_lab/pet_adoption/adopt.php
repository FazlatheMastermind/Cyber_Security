<?php
session_start();
include 'config/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "<h2>❌ Please login first</h2>";
    echo "<a href='login.php'>Go to Login</a>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pet_id = isset($_POST['pet_id']) ? $_POST['pet_id'] : 0;
    $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : $_SESSION['user_id'];
    
    // Check if pet exists
    $check_pet = mysqli_query($conn, "SELECT * FROM pets WHERE id = $pet_id");
    if (!$check_pet || mysqli_num_rows($check_pet) == 0) {
        echo "<h2>❌ Pet not found!</h2>";
        echo "<a href='index.php'>Go Home</a>";
        exit();
    }
    
    // Insert adoption request
    $query = "INSERT INTO adoptions (pet_id, user_id, status) VALUES ($pet_id, $user_id, 'pending')";
    
    if (mysqli_query($conn, $query)) {
        echo "<h2 style='color: green;'>✅ Adoption request submitted successfully!</h2>";
        echo "<p><strong>Pet ID:</strong> $pet_id</p>";
        echo "<p><strong>User ID:</strong> $user_id</p>";
        echo "<p><strong>Status:</strong> Pending</p>";
        echo "<br><a href='index.php' style='display: inline-block; padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>Go Home</a>";
    } else {
        echo "<h2 style='color: red;'>❌ Error: " . mysqli_error($conn) . "</h2>";
        echo "<a href='index.php'>Go Home</a>";
    }
} else {
    echo "<h2>❌ Invalid request method</h2>";
    echo "<a href='index.php'>Go Home</a>";
}
?>
