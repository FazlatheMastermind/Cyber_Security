<?php
session_start();
include 'config/db.php';

$message = "";
$id = isset($_GET['id']) ? $_GET['id'] : 0;

$query = "SELECT p.*, u.username as added_by_username 
          FROM pets p 
          LEFT JOIN users u ON p.added_by = u.id 
          WHERE p.id = $id";
$result = mysqli_query($conn, $query);
$pet = mysqli_fetch_assoc($result);

if (!$pet) {
    header("Location: available_pets.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $message_text = $_POST['message'];
    
    $adopt_query = "INSERT INTO adoptions (pet_id, user_id, message) 
                    VALUES ($id, $user_id, '$message_text')";
    
    if (mysqli_query($conn, $adopt_query)) {
        $update_query = "UPDATE pets SET status = 'pending' WHERE id = $id";
        mysqli_query($conn, $update_query);
        $message = "✅ Adoption request submitted successfully!";
    } else {
        $message = "❌ Error: " . mysqli_error($conn);
    }
}

$check_query = "SELECT * FROM adoptions WHERE pet_id = $id AND user_id = " . ($_SESSION['user_id'] ?? 0);
$check_result = mysqli_query($conn, $check_query);
$already_applied = $check_result && mysqli_num_rows($check_result) > 0;
?>
<?php include 'includes/header.php'; ?>

<div class="grid-2">
    <div>
        <div class="card">
            <h2><?php echo $pet['name']; ?></h2>
            <p style="color: #636e72; font-size: 16px;"><?php echo $pet['type']; ?> - <?php echo $pet['breed']; ?></p>
            
            <div style="margin: 15px 0;">
                <span class="pet-status status-<?php echo $pet['status']; ?>">
                    <?php echo ucfirst($pet['status']); ?>
                </span>
            </div>
            
            <div style="margin: 20px 0;">
                <p><strong>Age:</strong> <?php echo $pet['age']; ?> months</p>
                <p><strong>Added by:</strong> <?php echo $pet['added_by_username'] ?? 'Unknown'; ?></p>
            </div>
            
            <div style="margin: 20px 0;">
                <h3>Description</h3>
                <p><?php echo $pet['description']; ?></p>
            </div>
        </div>
    </div>
    
    <div>
        <?php if(isset($_SESSION['user_id'])): ?>
            <div class="card">
                <h3>Adopt <?php echo $pet['name']; ?></h3>
                
                <?php if($message): ?>
                <div class="message"><?php echo $message; ?></div>
                <?php endif; ?>
                
                <?php if($pet['status'] == 'available' && !$already_applied): ?>
                    <form method="POST">
                        <div class="form-group">
                            <label>Why do you want to adopt <?php echo $pet['name']; ?>?</label>
                            <textarea name="message" placeholder="Tell us about your home and why you want to adopt..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-success" style="width: 100%;">Submit Adoption Request</button>
                    </form>
                <?php elseif($already_applied): ?>
                    <div style="background: #ffeaa7; padding: 15px; border-radius: 5px;">
                        You have already applied to adopt <?php echo $pet['name']; ?>.
                    </div>
                <?php elseif($pet['status'] == 'pending'): ?>
                    <div style="background: #fdcb6e; padding: 15px; border-radius: 5px;">
                        This pet is currently pending adoption.
                    </div>
                <?php elseif($pet['status'] == 'adopted'): ?>
                    <div style="background: #b2bec3; padding: 15px; border-radius: 5px;">
                        This pet has been adopted. ❤️
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="card" style="margin-top: 20px;">
                <form method="POST" action="save_pet.php">
                    <input type="hidden" name="pet_id" value="<?php echo $pet['id']; ?>">
                    <button type="submit" class="btn btn-warning" style="width: 100%;">❤️ Save to Favorites</button>
                </form>
            </div>
        <?php else: ?>
            <div class="card">
                <p style="text-align: center;">Please <a href="login.php">login</a> to adopt this pet.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <h3>🐾 Other Pets You Might Like</h3>
    <?php
    $related_query = "SELECT * FROM pets WHERE type = '{$pet['type']}' AND id != $id LIMIT 3";
    $related_result = mysqli_query($conn, $related_query);
    ?>
    <div class="pet-grid">
        <?php while($related = mysqli_fetch_assoc($related_result)): ?>
            <div class="pet-card">
                <div class="pet-info">
                    <div class="pet-name"><?php echo $related['name']; ?></div>
                    <div class="pet-type"><?php echo $related['breed']; ?></div>
                    <a href="pet_details.php?id=<?php echo $related['id']; ?>" class="btn btn-primary" style="margin-top: 10px;">View Details</a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
