<?php
session_start();
include 'config/db.php';

$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
$search = isset($_GET['search']) ? $_GET['search'] : '';

if ($search) {
    $query = "SELECT * FROM pets WHERE name LIKE '%$search%' OR type LIKE '%$search%' OR breed LIKE '%$search%'";
    if ($filter != 'all') {
        $query .= " AND status = '$filter'";
    }
} else {
    $query = "SELECT * FROM pets";
    if ($filter != 'all') {
        $query .= " WHERE status = '$filter'";
    }
}
$query .= " ORDER BY created_at DESC";

$result = mysqli_query($conn, $query);
?>
<?php include 'includes/header.php'; ?>

<div class="card">
    <h2>🐾 Available Pets</h2>
    
    <div style="background: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;">
        <form method="GET" style="display: flex; gap: 15px; flex-wrap: wrap;">
            <input type="text" name="search" placeholder="Search by name, type, or breed..." style="flex: 2; min-width: 200px;" value="<?php echo htmlspecialchars($search); ?>">
            <select name="filter" style="flex: 1; min-width: 150px;">
                <option value="all" <?php echo $filter == 'all' ? 'selected' : ''; ?>>All Pets</option>
                <option value="available" <?php echo $filter == 'available' ? 'selected' : ''; ?>>Available</option>
                <option value="pending" <?php echo $filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                <option value="adopted" <?php echo $filter == 'adopted' ? 'selected' : ''; ?>>Adopted</option>
            </select>
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
    </div>
    
    <?php if($search): ?>
    <div style="background: #dfe6e9; padding: 10px; border-radius: 5px; margin: 10px 0;">
        Showing results for: <strong><?php echo $search; ?></strong>
    </div>
    <?php endif; ?>
    
    <div class="pet-grid">
        <?php if($result && mysqli_num_rows($result) > 0): ?>
            <?php while($pet = mysqli_fetch_assoc($result)): ?>
                <div class="pet-card">
                    <div class="pet-info">
                        <div class="pet-name"><?php echo $pet['name']; ?></div>
                        <div class="pet-type"><?php echo $pet['type']; ?> - <?php echo $pet['breed']; ?></div>
                        <div style="margin: 10px 0;">
                            <span class="pet-status status-<?php echo $pet['status']; ?>">
                                <?php echo ucfirst($pet['status']); ?>
                            </span>
                        </div>
                        <p style="color: #636e72; font-size: 14px; margin: 10px 0;">
                            <?php echo substr($pet['description'], 0, 100); ?>...
                        </p>
                        <div style="display: flex; gap: 10px; margin-top: 15px;">
                            <a href="pet_details.php?id=<?php echo $pet['id']; ?>" class="btn btn-primary" style="flex: 1; text-align: center; font-size: 14px; padding: 8px;">View Details</a>
                            <?php if(isset($_SESSION['user_id']) && $pet['status'] == 'available'): ?>
                                <a href="adopt.php?id=<?php echo $pet['id']; ?>" class="btn btn-success" style="font-size: 14px; padding: 8px 15px;">Adopt</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No pets found matching your criteria.</p>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
