<?php
session_start();
include 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

$query = "SELECT * FROM users WHERE id = $user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

if (isset($_POST['change_email'])) {
    $new_email = $_POST['new_email'];
    $update_query = "UPDATE users SET email = '$new_email' WHERE id = $user_id";
    if (mysqli_query($conn, $update_query)) {
        $message = "✅ Email updated successfully!";
        $result = mysqli_query($conn, $query);
        $user = mysqli_fetch_assoc($result);
    } else {
        $message = "❌ Error: " . mysqli_error($conn);
    }
}

if (isset($_POST['change_password'])) {
    $old_password = $_POST['old_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if ($old_password == $user['password']) {
        if ($new_password == $confirm_password) {
            $update_query = "UPDATE users SET password = '$new_password' WHERE id = $user_id";
            if (mysqli_query($conn, $update_query)) {
                $message = "✅ Password changed successfully!";
            } else {
                $message = "❌ Error: " . mysqli_error($conn);
            }
        } else {
            $message = "❌ New passwords do not match!";
        }
    } else {
        $message = "❌ Current password is incorrect!";
    }
}
?>
<?php include 'includes/header.php'; ?>

<div class="grid-2">
    <div class="card">
        <h2>👤 My Profile</h2>
        <div style="margin: 20px 0;">
            <p><strong>Username:</strong> <?php echo $user['username']; ?></p>
            <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
            <p><strong>Role:</strong> <?php echo ucfirst($user['role']); ?></p>
            <p><strong>Member since:</strong> <?php echo date('M d, Y', strtotime($user['created_at'])); ?></p>
        </div>
    </div>
    
    <div class="card">
        <h2>📧 Change Email</h2>
        <?php if($message): ?>
        <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <input type="hidden" name="change_email" value="1">
            <div class="form-group">
                <label>New Email Address</label>
                <input type="email" name="new_email" value="<?php echo $user['email']; ?>" required>
            </div>
            <button type="submit" class="btn btn-primary" style="width: 100%;">Update Email</button>
        </form>
    </div>
</div>

<div class="card">
    <h2>🔒 Change Password</h2>
    
    <form method="POST">
        <input type="hidden" name="change_password" value="1">
        <div class="form-group">
            <label>Current Password</label>
            <input type="password" name="old_password" required>
        </div>
        <div class="form-group">
            <label>New Password</label>
            <input type="password" name="new_password" required>
        </div>
        <div class="form-group">
            <label>Confirm New Password</label>
            <input type="password" name="confirm_password" required>
        </div>
        <button type="submit" class="btn btn-success" style="width: 100%;">Change Password</button>
    </form>
</div>

<div class="card">
    <h3>📊 My Adoption Stats</h3>
    <?php
    $stats_query = "SELECT status, COUNT(*) as count FROM adoptions WHERE user_id = $user_id GROUP BY status";
    $stats_result = mysqli_query($conn, $stats_query);
    $stats = [];
    while($row = mysqli_fetch_assoc($stats_result)) {
        $stats[$row['status']] = $row['count'];
    }
    ?>
    <div style="display: flex; gap: 20px; margin-top: 15px; flex-wrap: wrap;">
        <div style="flex: 1; text-align: center; padding: 15px; background: #f8f9fa; border-radius: 5px;">
            <strong>Pending</strong>
            <p style="font-size: 24px; color: #fdcb6e;"><?php echo $stats['pending'] ?? 0; ?></p>
        </div>
        <div style="flex: 1; text-align: center; padding: 15px; background: #f8f9fa; border-radius: 5px;">
            <strong>Approved</strong>
            <p style="font-size: 24px; color: #00b894;"><?php echo $stats['approved'] ?? 0; ?></p>
        </div>
        <div style="flex: 1; text-align: center; padding: 15px; background: #f8f9fa; border-radius: 5px;">
            <strong>Rejected</strong>
            <p style="font-size: 24px; color: #e17055;"><?php echo $stats['rejected'] ?? 0; ?></p>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
