<?php
session_start();
include 'config/db.php';

$message = "";
$message_type = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if fields are empty
    if (empty($_POST['username']) || empty($_POST['email']) || empty($_POST['password'])) {
        $message = "❌ All fields are required!";
        $message_type = "error";
    } else {
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = $_POST['password'];
        
        // Check if username or email already exists
        $check_query = "SELECT id FROM users WHERE username = '$username' OR email = '$email'";
        $check_result = mysqli_query($conn, $check_query);
        
        if ($check_result && mysqli_num_rows($check_result) > 0) {
            $message = "❌ Username or email already exists! Please choose different ones.";
            $message_type = "error";
        } else {
            // Insert new user (using plain text for now to match existing data)
            $query = "INSERT INTO users (username, email, password, role) 
                      VALUES ('$username', '$email', '$password', 'user')";
            
            if (mysqli_query($conn, $query)) {
                $message = "✅ Registration successful! Please <a href='login.php'>login here</a>";
                $message_type = "success";
            } else {
                $message = "❌ Registration failed: " . mysqli_error($conn);
                $message_type = "error";
            }
        }
    }
}
?>
<?php include 'includes/header.php'; ?>

<div class="card" style="max-width: 500px; margin: 40px auto;">
    <h2 style="text-align: center; margin-bottom: 30px;">📝 Register for Pet Adoption</h2>
    
    <?php if($message): ?>
    <div style="padding: 10px; border-radius: 5px; margin-bottom: 20px; border: 1px solid <?php echo ($message_type == 'success') ? '#c3e6cb' : '#f5c6cb'; ?>; background: <?php echo ($message_type == 'success') ? '#d4edda' : '#f8d7da'; ?>; color: <?php echo ($message_type == 'success') ? '#155724' : '#721c24'; ?>;">
        <?php echo $message; ?>
    </div>
    <?php endif; ?>
    
    <form method="POST">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" placeholder="Choose a username" required style="width: 100%; padding: 10px; margin: 5px 0 15px 0; border: 1px solid #ddd; border-radius: 5px;">
        </div>
        <div class="form-group">
            <label>Email Address</label>
            <input type="email" name="email" placeholder="Enter your email" required style="width: 100%; padding: 10px; margin: 5px 0 15px 0; border: 1px solid #ddd; border-radius: 5px;">
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Choose a password" required style="width: 100%; padding: 10px; margin: 5px 0 15px 0; border: 1px solid #ddd; border-radius: 5px;">
        </div>
        <button type="submit" class="btn btn-success" style="width: 100%; padding: 12px; background: #00b894; color: white; border: none; border-radius: 5px; font-size: 16px; cursor: pointer;">Register</button>
    </form>
    
    <p style="text-align: center; margin-top: 20px;">
        Already have an account? <a href="login.php" style="color: #667eea;">Login here</a>
    </p>
</div>

<?php include 'includes/footer.php'; ?>
