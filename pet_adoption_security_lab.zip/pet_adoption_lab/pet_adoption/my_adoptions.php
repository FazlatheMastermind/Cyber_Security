<?php
session_start();
include 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$query = "SELECT a.*, p.name as pet_name, p.type, p.breed, p.status as pet_status 
          FROM adoptions a 
          JOIN pets p ON a.pet_id = p.id 
          WHERE a.user_id = $user_id 
          ORDER BY a.application_date DESC";
$result = mysqli_query($conn, $query);
?>
<?php include 'includes/header.php'; ?>

<div class="card">
    <h2>📋 My Adoption Requests</h2>
    
    <?php if($result && mysqli_num_rows($result) > 0): ?>
        <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
            <thead>
                <tr style="background: #f8f9fa; border-bottom: 2px solid #dfe6e9;">
                    <th style="padding: 12px; text-align: left;">Pet</th>
                    <th style="padding: 12px; text-align: left;">Type</th>
                    <th style="padding: 12px; text-align: left;">Status</th>
                    <th style="padding: 12px; text-align: left;">Application Date</th>
                    <th style="padding: 12px; text-align: left;">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while($adoption = mysqli_fetch_assoc($result)): ?>
                    <tr style="border-bottom: 1px solid #dfe6e9;">
                        <td style="padding: 12px;">
                            <strong><?php echo $adoption['pet_name']; ?></strong>
                        </td>
                        <td style="padding: 12px;"><?php echo $adoption['type']; ?></td>
                        <td style="padding: 12px;">
                            <span style="display: inline-block; padding: 3px 12px; border-radius: 15px; font-size: 12px; font-weight: 600;
                                <?php if($adoption['status'] == 'approved'): ?>background: #00b894; color: white;
                                <?php elseif($adoption['status'] == 'pending'): ?>background: #fdcb6e; color: #2d3436;
                                <?php else: ?>background: #e17055; color: white;<?php endif; ?>">
                                <?php echo ucfirst($adoption['status']); ?>
                            </span>
                        </td>
                        <td style="padding: 12px;"><?php echo date('M d, Y', strtotime($adoption['application_date'])); ?></td>
                        <td style="padding: 12px;">
                            <a href="pet_details.php?id=<?php echo $adoption['pet_id']; ?>" class="btn btn-primary" style="font-size: 12px; padding: 5px 15px;">View Pet</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="text-align: center; padding: 40px 0; color: #636e72;">
            You haven't submitted any adoption requests yet.
            <br><br>
            <a href="available_pets.php" class="btn btn-primary">Browse Available Pets</a>
        </p>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
