</div>
<div class="footer">
    <p>🐾 Pet Adoption Platform - <span style="color: #e74c3c;">VULNERABLE VERSION - Educational Purpose Only</span></p>
    <p style="font-size: 12px; margin-top: 5px;">
        <span class="vuln-badge">SQL Injection</span>
        <span class="vuln-badge">XSS</span>
        <span class="vuln-badge">CSRF</span>
        <span class="vuln-badge">CORS</span>
        <span class="vuln-badge">XXE</span>
    </p>
</div>
</body>
</html>
