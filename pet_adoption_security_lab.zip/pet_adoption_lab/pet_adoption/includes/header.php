<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Adoption Platform</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f4f4f4; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        nav { background: #2d3436; padding: 15px 0; margin-bottom: 20px; border-radius: 8px; }
        nav .container { display: flex; justify-content: space-between; align-items: center; }
        nav a { color: white; text-decoration: none; padding: 10px 15px; }
        nav a:hover { background: #4a5568; border-radius: 4px; }
        .btn { display: inline-block; padding: 10px 20px; border-radius: 5px; text-decoration: none; }
        .btn-primary { background: #667eea; color: white; }
        .btn-primary:hover { background: #5a67d8; }
        .btn-warning { background: #f6ad55; color: white; }
        .btn-warning:hover { background: #ed8936; }
        .card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin: 20px 0; }
        .pet-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; margin: 20px 0; }
        .pet-card { background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.1); transition: transform 0.2s; }
        .pet-card:hover { transform: translateY(-5px); }
        .pet-info { padding: 15px; }
        .pet-name { font-size: 20px; font-weight: bold; color: #2d3436; }
        .pet-type { color: #636e72; font-size: 14px; margin: 5px 0; }
        .pet-status { display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 12px; font-weight: bold; }
        .status-available { background: #c6f6d5; color: #276749; }
        .status-pending { background: #fefcbf; color: #975a16; }
        .status-adopted { background: #fed7d7; color: #9b2c2c; }
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        @media (max-width: 768px) { .grid-2 { grid-template-columns: 1fr; } }
        footer { text-align: center; padding: 20px; color: #a0aec0; }
    </style>
</head>
<body>
    <nav>
        <div class="container">
            <div>
                <a href="index.php" style="font-weight: bold; font-size: 20px;">🐾 PetAdopt</a>
                <a href="index.php">Home</a>
                <a href="available_pets.php">Available Pets</a>
                <a href="feedback.php">Feedback</a>
            </div>
            <div>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <span style="color: white;">Welcome, <?php echo $_SESSION['username'] ?? 'User'; ?></span>
                    <a href="profile.php">Profile</a>
                    <a href="logout.php">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                    <a href="register.php">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <div class="container">
