<?php
session_start();
include 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$pet_id = isset($_POST['pet_id']) ? $_POST['pet_id'] : (isset($_GET['id']) ? $_GET['id'] : 0);

$query = "INSERT INTO saved_pets (user_id, pet_id) VALUES ($user_id, $pet_id)";
mysqli_query($conn, $query);

header("Location: " . ($_SERVER['HTTP_REFERER'] ?? 'index.php'));
exit();
?>
