<?php
session_start();
include 'config/db.php';

$limit = isset($_GET['limit']) ? $_GET['limit'] : 6;

$query = "SELECT * FROM pets WHERE status = 'available' ORDER BY created_at DESC LIMIT $limit";
$result = mysqli_query($conn, $query);
?>
<?php include 'includes/header.php'; ?>

<div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 60px 20px; border-radius: 15px; text-align: center; color: white; margin: 20px 0;">
    <h1 style="font-size: 48px; margin-bottom: 20px;">🐾 Find Your Furry Friend</h1>
    <p style="font-size: 20px; opacity: 0.9;">Every pet deserves a loving home. Start your adoption journey today!</p>
    <div style="margin-top: 30px;">
        <a href="available_pets.php" class="btn" style="background: white; color: #667eea; padding: 15px 40px; font-size: 18px;">Browse Available Pets</a>
    </div>
</div>

<div class="card">
    <h2>🐶 Recently Added Pets</h2>
    
    <?php if(isset($_GET['limit'])): ?>
    <div style="background: #ffeaa7; padding: 10px; border-radius: 5px; margin: 10px 0;">
        Showing limited results: <?php echo $_GET['limit']; ?>
    </div>
    <?php endif; ?>
    
    <div class="pet-grid">
        <?php if($result && mysqli_num_rows($result) > 0): ?>
            <?php while($pet = mysqli_fetch_assoc($result)): ?>
                <div class="pet-card">
                    <div class="pet-info">
                        <div class="pet-name"><?php echo $pet['name']; ?></div>
                        <div class="pet-type"><?php echo $pet['type']; ?> - <?php echo $pet['breed']; ?></div>
                        <div style="margin: 10px 0;">
                            <span class="pet-status status-<?php echo $pet['status']; ?>">
                                <?php echo ucfirst($pet['status']); ?>
                            </span>
                        </div>
                        <p style="color: #636e72; font-size: 14px; margin: 10px 0;">
                            <?php echo substr($pet['description'], 0, 100); ?>...
                        </p>
                        <div style="display: flex; gap: 10px; margin-top: 15px;">
                            <a href="pet_details.php?id=<?php echo $pet['id']; ?>" class="btn btn-primary" style="flex: 1; text-align: center; font-size: 14px; padding: 8px;">View Details</a>
                            <?php if(isset($_SESSION['user_id'])): ?>
                                <a href="save_pet.php?id=<?php echo $pet['id']; ?>" class="btn btn-warning" style="font-size: 14px; padding: 8px 15px;">❤️</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No pets available at the moment.</p>
        <?php endif; ?>
    </div>
    
    <div style="text-align: center; margin-top: 20px;">
        <a href="available_pets.php" class="btn btn-primary">View All Pets</a>
    </div>
</div>

<div class="grid-2" style="margin: 20px 0;">
    <div class="card" style="text-align: center;">
        <h3>🏠 Pets Available</h3>
        <?php
        $count_query = "SELECT COUNT(*) as count FROM pets WHERE status = 'available'";
        $count_result = mysqli_query($conn, $count_query);
        $count = mysqli_fetch_assoc($count_result);
        ?>
        <p style="font-size: 36px; color: #00b894; font-weight: 700;"><?php echo $count['count']; ?></p>
    </div>
    <div class="card" style="text-align: center;">
        <h3>❤️ Happy Adoptions</h3>
        <?php
        $adopted_query = "SELECT COUNT(*) as count FROM pets WHERE status = 'adopted'";
        $adopted_result = mysqli_query($conn, $adopted_query);
        $adopted = mysqli_fetch_assoc($adopted_result);
        ?>
        <p style="font-size: 36px; color: #667eea; font-weight: 700;"><?php echo $adopted['count']; ?></p>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
