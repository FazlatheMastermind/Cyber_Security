<?php
$host = 'localhost';
$dbname = 'pet_adoption';
$username = 'pet_admin';
$password = 'pet123';

// MySQLi connection (for vulnerable pages)
$conn = mysqli_connect($host, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8mb4");

// PDO connection (for other pages) - with error handling that doesn't crash
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    // Set error mode to exception, but we'll catch it
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    // Just log it, don't die
    error_log("PDO Connection failed: " . $e->getMessage());
    $pdo = null;
}

// For debugging - uncomment to test connection
// echo "Database connection successful!";
?>
