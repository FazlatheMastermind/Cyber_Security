<?php
session_start();
include 'config/db.php';

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $comment = $_POST['comment'];
    $rating = $_POST['rating'];
    
    // 🔓 EXTREMELY VULNERABLE - No sanitization at all!
    $query = "INSERT INTO feedback (user_id, comment, rating) VALUES ($user_id, '$comment', $rating)";
    
    // Show the query for debugging
    echo "<div style='background: #1a1a2e; color: #00ff00; padding: 15px; margin: 20px; border-radius: 5px; font-family: monospace;'>";
    echo "<strong>🔍 SQL Query:</strong><br>" . htmlspecialchars($query);
    echo "</div>";
    
    if (mysqli_query($conn, $query)) {
        $message = "✅ Feedback submitted successfully!";
    } else {
        $message = "❌ Error: " . mysqli_error($conn);
    }
}

// 🔓 VULNERABLE - Displays raw HTML without sanitization
$feedback_query = "SELECT f.*, u.username FROM feedback f JOIN users u ON f.user_id = u.id ORDER BY f.created_at DESC";
$feedback_result = mysqli_query($conn, $feedback_query);
?>
<?php include 'includes/header.php'; ?>

<div class="grid-2">
    <div class="card">
        <h2>💬 Share Your Feedback</h2>
        
        <?php if(!isset($_SESSION['user_id'])): ?>
            <p>Please <a href="login.php">login</a> to submit feedback.</p>
        <?php else: ?>
            <?php if($message): ?>
            <div class="message"><?php echo $message; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label>Your Comment</label>
                    <textarea name="comment" placeholder="Enter your feedback (XSS allowed!)" required></textarea>
                </div>
                <div class="form-group">
                    <label>Rating</label>
                    <select name="rating" required>
                        <option value="5">⭐⭐⭐⭐⭐ - Excellent</option>
                        <option value="4">⭐⭐⭐⭐ - Good</option>
                        <option value="3">⭐⭐⭐ - Average</option>
                        <option value="2">⭐⭐ - Poor</option>
                        <option value="1">⭐ - Very Poor</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%;">Submit Feedback</button>
            </form>
        <?php endif; ?>
    </div>
    
    <div class="card">
        <h2>📝 User Feedback</h2>
        
        <?php if($feedback_result && mysqli_num_rows($feedback_result) > 0): ?>
            <?php while($feedback = mysqli_fetch_assoc($feedback_result)): ?>
                <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <strong><?php echo $feedback['username']; ?></strong>
                        <span style="color: #fdcb6e; font-size: 18px;">
                            <?php echo str_repeat('⭐', $feedback['rating']); ?>
                        </span>
                    </div>
                    <!-- 🔓 EXTREMELY VULNERABLE - Raw output, NO sanitization -->
                    <p style="margin-top: 10px;"><?php echo $feedback['comment']; ?></p>
                    <small style="color: #636e72;">
                        <?php echo date('M d, Y', strtotime($feedback['created_at'])); ?>
                    </small>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p style="text-align: center; color: #636e72;">No feedback yet. Be the first!</p>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
