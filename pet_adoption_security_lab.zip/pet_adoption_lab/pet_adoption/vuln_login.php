<?php
session_start();

// Include database connection
$host = 'localhost';
$dbname = 'pet_adoption';
$username = 'pet_admin';
$password = 'pet123';

// Use MySQLi (not PDO)
$conn = mysqli_connect($host, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8mb4");

$result_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user input
    $email = $_POST['email'];
    $pass = $_POST['password'];
    
    // 🔓 VULNERABLE QUERY - Direct concatenation
    $query = "SELECT * FROM users WHERE email = '$email'";
    
    // Execute query
    $result = mysqli_query($conn, $query);
    
    // Show the query for debugging
    $result_message .= "<div style='background: #1a1a2e; color: #00d2ff; padding: 15px; border-radius: 5px; margin: 15px 0; font-family: monospace; font-size: 13px;'>";
    $result_message .= "<strong>🔍 SQL Query:</strong><br>" . htmlspecialchars($query) . "</div>";
    
    if ($result) {
        $user = mysqli_fetch_assoc($result);
        
        if ($user) {
            // Check if password matches (plain text)
            if ($pass == $user['password']) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['logged_in'] = true;
                
                $result_message .= "<div style='background: #00b894; color: white; padding: 20px; border-radius: 5px; margin: 15px 0;'>";
                $result_message .= "<h3>✅ Login Successful!</h3>";
                $result_message .= "Welcome <strong>" . $user['username'] . "</strong> (Role: " . $user['role'] . ")<br>";
                $result_message .= "<a href='index.php' style='display: inline-block; margin-top: 10px; padding: 10px 20px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;'>Go to Home</a>";
                $result_message .= "</div>";
            } else {
                $result_message .= "<div style='background: #ffd93d; color: #1a1a2e; padding: 15px; border-radius: 5px; margin: 15px 0;'>";
                $result_message .= "❌ Incorrect password for user: " . $user['username'];
                $result_message .= "</div>";
            }
        } else {
            $result_message .= "<div style='background: #ff4757; color: white; padding: 15px; border-radius: 5px; margin: 15px 0;'>";
            $result_message .= "❌ User not found with email: " . htmlspecialchars($email);
            $result_message .= "</div>";
        }
    } else {
        $result_message .= "<div style='background: #ff4757; color: white; padding: 15px; border-radius: 5px; margin: 15px 0;'>";
        $result_message .= "❌ SQL Error: " . mysqli_error($conn);
        $result_message .= "</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Vulnerable Login - SQL Injection</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: Arial, sans-serif; 
            background: #0f0f1a; 
            display: flex; 
            justify-content: center; 
            align-items: center; 
            min-height: 100vh; 
            padding: 20px;
        }
        .container { 
            background: #1a1a2e; 
            padding: 40px; 
            border-radius: 15px; 
            width: 500px; 
            max-width: 100%;
            border: 2px solid #ff4757;
            box-shadow: 0 0 50px rgba(255, 71, 87, 0.2);
        }
        h1 { 
            text-align: center; 
            color: white; 
            margin-bottom: 10px;
        }
        .badge { 
            background: #ff4757; 
            color: white; 
            padding: 5px 15px; 
            border-radius: 5px; 
            display: inline-block;
            font-size: 14px;
            animation: blink 1s infinite;
        }
        @keyframes blink {
            0% { opacity: 1; }
            50% { opacity: 0.3; }
            100% { opacity: 1; }
        }
        .subtitle { 
            text-align: center; 
            color: #aaa; 
            margin-bottom: 20px;
            font-size: 14px;
        }
        .payloads { 
            background: #0f3460; 
            padding: 15px; 
            border-radius: 8px; 
            margin: 20px 0;
            border-left: 3px solid #ff4757;
        }
        .payloads strong { 
            color: #ffd93d; 
            display: block; 
            margin-bottom: 10px;
        }
        .payloads code { 
            color: #ff6b6b; 
            display: block; 
            padding: 5px 10px; 
            margin: 3px 0;
            background: #1a1a2e;
            border-radius: 3px;
            font-size: 13px;
            font-family: 'Courier New', monospace;
        }
        .payloads .label { 
            color: #aaa; 
            font-size: 11px; 
            margin-top: 5px;
            display: block;
        }
        .form-group { 
            margin: 15px 0; 
        }
        .form-group label { 
            color: white; 
            display: block; 
            margin-bottom: 5px;
            font-size: 14px;
        }
        .form-group input { 
            width: 100%; 
            padding: 12px; 
            border-radius: 8px; 
            border: 1px solid #333;
            background: #0f3460;
            color: white;
            font-size: 14px;
            box-sizing: border-box;
        }
        .form-group input:focus { 
            outline: none; 
            border-color: #ff4757;
        }
        button { 
            width: 100%; 
            padding: 14px; 
            background: #ff4757; 
            color: white; 
            border: none; 
            border-radius: 8px; 
            font-size: 16px; 
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover { 
            background: #ff3838; 
        }
        .result { 
            margin-top: 20px; 
        }
        .nav-links { 
            text-align: center; 
            margin-top: 20px; 
            padding-top: 20px;
            border-top: 1px solid #333;
        }
        .nav-links a { 
            color: #00d2ff; 
            text-decoration: none; 
            font-size: 13px;
            margin: 0 10px;
        }
        .nav-links a:hover { 
            text-decoration: underline; 
        }
        .test-creds {
            background: #0f3460;
            padding: 12px;
            border-radius: 5px;
            margin: 15px 0;
            font-size: 13px;
            color: #aaa;
        }
        .test-creds strong { color: #ffd93d; }
    </style>
</head>
<body>
    <div class="container">
        <h1>
            <span class="badge">🔓 VULNERABLE</span><br>
            SQL Injection Login
        </h1>
        <p class="subtitle">This page is intentionally vulnerable for security testing</p>
        
        <div class="test-creds">
            <strong>✅ Valid Credentials (for testing):</strong><br>
            Admin: admin@petadoption.com / admin123<br>
            User: john@email.com / password123
        </div>
        
        <div class="payloads">
            <strong>💉 SQL Injection Payloads (copy & paste into email field):</strong>
            <span class="label">Basic Bypass:</span>
            <code>' OR '1'='1' -- </code>
            <span class="label">Login as Admin:</span>
            <code>admin@petadoption.com' -- </code>
            <span class="label">Alternative Bypass:</span>
            <code>' OR 1=1#</code>
            <span class="label">Union Injection:</span>
            <code>' UNION SELECT 1, 'hacker', 'hack@email.com', 'pass', 'admin' -- </code>
        </div>
        
        <form method="POST">
            <div class="form-group">
                <label>📧 Email Address (inject here)</label>
                <input type="text" name="email" placeholder="Enter email or SQL payload" required>
            </div>
            <div class="form-group">
                <label>🔑 Password (can be anything)</label>
                <input type="text" name="password" placeholder="Enter anything" required>
            </div>
            <button type="submit">🚀 Login (Vulnerable)</button>
        </form>
        
        <?php if($result_message): ?>
        <div class="result">
            <?php echo $result_message; ?>
        </div>
        <?php endif; ?>
        
        <div class="nav-links">
            <a href="login.php">🔒 Normal Login</a>
            <a href="index.php">🏠 Home</a>
        </div>
    </div>
</body>
</html>
