<?php
session_start();
include 'config/db.php';

$results = [];
$search_term = '';

if (isset($_GET['q'])) {
    $search_term = $_GET['q'];
    $query = "SELECT * FROM pets WHERE 
              name LIKE '%$search_term%' OR 
              type LIKE '%$search_term%' OR 
              breed LIKE '%$search_term%' OR 
              description LIKE '%$search_term%'";
    $result = mysqli_query($conn, $query);
    if ($result) {
        $results = mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
}
?>
<?php include 'includes/header.php'; ?>

<div class="card">
    <h2>🔍 Search Pets</h2>
    
    <form method="GET" style="margin: 20px 0;">
        <div style="display: flex; gap: 15px;">
            <input type="text" name="q" placeholder="Search for pets..." style="flex: 1;" value="<?php echo htmlspecialchars($search_term); ?>">
            <button type="submit" class="btn btn-primary">Search</button>
        </div>
    </form>
    
    <?php if($search_term): ?>
    <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 15px 0;">
        Search results for: <strong><?php echo $search_term; ?></strong>
        (Found <?php echo count($results); ?> results)
    </div>
    
    <div class="pet-grid">
        <?php foreach($results as $pet): ?>
            <div class="pet-card">
                <div class="pet-info">
                    <div class="pet-name"><?php echo $pet['name']; ?></div>
                    <div class="pet-type"><?php echo $pet['type']; ?></div>
                    <span class="pet-status status-<?php echo $pet['status']; ?>">
                        <?php echo ucfirst($pet['status']); ?>
                    </span>
                    <p style="color: #636e72; font-size: 14px; margin-top: 10px;">
                        <?php echo substr($pet['description'], 0, 100); ?>...
                    </p>
                    <a href="pet_details.php?id=<?php echo $pet['id']; ?>" class="btn btn-primary" style="margin-top: 10px;">View Details</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
