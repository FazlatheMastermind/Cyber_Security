# 🐾 Pet Adoption Platform - Security Testing Lab

## 📋 Overview
A deliberately vulnerable web application for security testing and education.

## 🚀 Quick Setup

### 1. Copy files to web root:
```bash
sudo cp -r ../pet_adoption/* /var/www/html/pet_adoption/
